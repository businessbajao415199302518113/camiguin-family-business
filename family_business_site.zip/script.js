// script.js
// Placeholder for future interactivity
console.log("Website loaded successfully.");
